// Console tab — live authenticity challenge. Wire-transfer voice auth scenario.
// Shows: incoming challenge, 4-memory-layer readout, verdict, killer SQL query.

const ConsoleTab = () => {
  const [attack, setAttack] = useState(false);     // toggle authentic vs clone
  const [queryRan, setQueryRan] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [challenge, setChallenge] = useState(null);
  const [layers, setLayers] = useState(null);

  // Try backend; if null, we render placeholders.
  useEffect(() => {
    AML_API.getChallenge("current").then(setChallenge);
    AML_API.runLayerQuery("current").then(setLayers);
  }, []);

  // Fake elapsed counter for the "live" feel; real latency comes from backend.
  useEffect(() => {
    if (!queryRan) return;
    const t0 = performance.now();
    let raf;
    const tick = () => {
      setElapsed(performance.now() - t0);
      if (performance.now() - t0 < 97) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [queryRan]);

  const runQuery = () => { setQueryRan(false); setTimeout(()=>setQueryRan(true), 20); };

  // Derived display (from backend if present, else BH placeholders)
  const F = (backend, placeholder) =>
    backend != null ? backend : <BackendHook name={placeholder} />;

  return (
    <div className="paper" style={{minHeight:"100vh", padding:"24px 32px 64px"}}>
      {/* ── case header ───────────────────────────────────────────── */}
      <div style={{display:"grid", gridTemplateColumns:"1fr auto", gap:24, alignItems:"start", marginBottom:16}}>
        <div>
          <Eyebrow>Case / Live Challenge</Eyebrow>
          <div style={{display:"flex", alignItems:"baseline", gap:18, marginTop:6, flexWrap:"wrap"}}>
            <div className="serif" style={{fontSize:"var(--t-7)", lineHeight:1, letterSpacing:"-0.02em"}}>
              Wire authorization &mdash; $250,000
            </div>
            <Tag tone={attack?"alarm":"verify"}>
              <Dot tone={attack?"alarm":"verify"} pulse /> {attack ? "Clone attempt" : "Live caller"}
            </Tag>
          </div>
          <div style={{marginTop:8, color:"var(--ink-3)", fontSize:"var(--t-3)"}}>
            Challenge <span className="num">{F(challenge?.id, "challenge.id")}</span>
            &nbsp;·&nbsp; Customer <span className="num">{F(challenge?.customer_id, "customer.id")}</span>
            &nbsp;·&nbsp; Tenant <span>{F(challenge?.tenant, "tenant.name")}</span>
            &nbsp;·&nbsp; Modality <span className="caps">voice</span>
          </div>
        </div>

        <div style={{display:"flex", gap:8, alignItems:"center"}}>
          <button className="btn" onClick={()=>setAttack(!attack)}>
            Toggle {attack ? "authentic caller" : "clone attempt"}
          </button>
          <button className={`btn primary`} onClick={runQuery}>
            Run 4-layer query
          </button>
        </div>
      </div>

      <Rule dotted style={{margin:"8px 0 20px"}} />

      {/* ── 4-column evidence grid: waveform / fingerprints / episodic / policy */}
      <div style={{display:"grid", gridTemplateColumns:"1.2fr 1fr 1fr 1fr", gap:18, marginBottom:20}}>
        {/* signal / waveform card */}
        <Xhair>
          <Card title="L1 · Active challenge" right="tikv · transactional">
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:6}}>
              <span className="eyebrow">inbound sample</span>
              <span className="eyebrow num">00:00:{attack?"31":"44"}</span>
            </div>
            <Wave seed={attack?9:3} tone={attack?"var(--alarm)":"var(--ink)"} attack={attack}/>
            <Rule dashed style={{margin:"10px 0"}}/>
            <KV rows={[
              ["asset hash", <span className="num">{F(challenge?.hash, "sha256")}</span>],
              ["sample_rate", "48 kHz"],
              ["channel", "telephony · PSTN"],
              ["device", F(challenge?.device, "device.fingerprint")],
              ["geo / asn", F(challenge?.geo, "geo · asn")],
            ]}/>
          </Card>
        </Xhair>

        {/* L2 semantic */}
        <Xhair>
          <Card title="L2 · Fingerprints" right="vector · hnsw">
            <div className="eyebrow" style={{marginBottom:6}}>distance from authentic</div>
            <DistBar value={attack?0.42:0.08} tone={attack?"alarm":"verify"}/>
            <div style={{display:"flex", justifyContent:"space-between", fontSize:"var(--t-1)", color:"var(--ink-3)"}}>
              <span>0.00 identical</span><span>1.00 disjoint</span>
            </div>
            <Rule dashed style={{margin:"12px 0"}}/>
            <div className="eyebrow" style={{marginBottom:6}}>distance from nearest attack</div>
            <DistBar value={attack?0.06:0.78} tone={attack?"alarm":"ink"} invert/>
            <Rule dashed style={{margin:"12px 0"}}/>
            <KV rows={[
              ["speaker emb", "ECAPA-TDNN · 192d"],
              ["baseline n", F(null, "authentic.count")],
              ["negative corpus", F(null, "attacks.count")],
            ]}/>
          </Card>
        </Xhair>

        {/* L3 episodic */}
        <Xhair>
          <Card title="L3 · Episodic" right="tiflash · htap">
            <Eyebrow>90-day verdict trajectory</Eyebrow>
            <div style={{marginTop:8}}>
              <Spark
                data={[0.04,0.06,0.03,0.05,0.04,0.07,0.05,0.06,0.04,0.03,0.05,0.06,0.08,0.05,0.06]
                  .concat(attack?[0.12,0.18,0.22,0.31]:[0.05,0.06,0.04,0.05])}
                width={260} height={48}
                tone={attack?"var(--alarm)":"var(--ink)"}/>
            </div>
            <Rule dashed style={{margin:"10px 0"}}/>
            <KV rows={[
              ["events · 90d", F(null, "events.n")],
              ["flagged · 90d", <span style={{color: attack?"var(--alarm)":"var(--ink)"}}>{F(null,"flagged.n")}</span>],
              ["human override", F(null, "override.rate")],
              ["last ground truth", F(null, "gt.outcome")],
            ]}/>
          </Card>
        </Xhair>

        {/* L4 policy */}
        <Xhair>
          <Card title="L4 · Policy" right="versioned · sql">
            <Eyebrow>active policy</Eyebrow>
            <div style={{
              fontFamily:"var(--mono)", fontSize:"var(--t-2)",
              background:"var(--paper-2)", border:"var(--solid)",
              padding:10, marginTop:6, lineHeight:1.5
            }}>
              <div>policy.v &nbsp; {F(null, "policy.version")}</div>
              <div>risk_tier &nbsp; {F(null, "risk.tier")}</div>
              <div>thresh_auth &nbsp; 0.18</div>
              <div>thresh_atk &nbsp; 0.25</div>
              <div style={{marginTop:6, color:"var(--ink-3)"}}>if auth &gt; 0.18 OR atk &lt; 0.25 OR txn&gt;$10k</div>
              <div style={{color:"var(--ink-3)"}}>&nbsp;&nbsp;then escalate.human &lt; 30s</div>
            </div>
            <Rule dashed style={{margin:"10px 0"}}/>
            <KV rows={[
              ["last promoted", F(null, "policy.promoted_at")],
              ["confidence", F(null, "policy.confidence")],
            ]}/>
          </Card>
        </Xhair>
      </div>

      {/* ── verdict + latency strip */}
      <div style={{
        display:"grid", gridTemplateColumns:"auto 1fr auto", gap:20, alignItems:"center",
        border: "1px solid var(--ink)", background:"var(--paper)", padding:"14px 18px", marginBottom:20
      }}>
        <div style={{display:"flex", gap:14, alignItems:"center"}}>
          <Stamp tone={attack?"alarm":"verify"}>
            {attack ? "Escalate · Human" : "Accept · Authentic"}
          </Stamp>
          <div>
            <Eyebrow>verdict</Eyebrow>
            <div style={{fontSize:"var(--t-4)", marginTop:2}}>
              {attack
                ? <span>Clone probability <span className="num">0.94</span> &nbsp;·&nbsp; attack cluster <span className="num">AX-418</span></span>
                : <span>Authenticity <span className="num">0.96</span> &nbsp;·&nbsp; baseline match <span className="num">0.92</span></span>}
            </div>
          </div>
        </div>

        <div style={{borderLeft:"var(--dash)", paddingLeft:18}}>
          <Eyebrow>signed latency trail</Eyebrow>
          <div style={{display:"flex", gap:18, marginTop:6, fontVariantNumeric:"tabular-nums"}}>
            <LatencyLeg label="parse"  ms={3}  />
            <LatencyLeg label="vec·l2" ms={queryRan?12:null}/>
            <LatencyLeg label="htap·l3" ms={queryRan?41:null}/>
            <LatencyLeg label="policy·l4" ms={queryRan?7:null}/>
            <LatencyLeg label="verdict" ms={queryRan?3:null}/>
            <div>
              <Eyebrow>total</Eyebrow>
              <div style={{fontSize:"var(--t-5)"}} className="num">
                {queryRan ? Math.min(97, Math.round(elapsed)+66) : "—"}<span style={{fontSize:"var(--t-3)", color:"var(--ink-3)"}}>ms</span>
              </div>
            </div>
          </div>
        </div>

        <div style={{textAlign:"right"}}>
          <Eyebrow>decision id</Eyebrow>
          <div className="num" style={{fontSize:"var(--t-3)"}}>{F(null, "decision.id")}</div>
          <div style={{marginTop:4}}><Tag tone="ghost">SIGNED · ED25519</Tag></div>
        </div>
      </div>

      {/* ── killer SQL + result */}
      <div style={{display:"grid", gridTemplateColumns:"1.5fr 1fr", gap:18}}>
        <Card title="The query · four layers · one statement" right="tidb · htap + vector + sql">
          <pre style={{
            margin:0, fontFamily:"var(--mono)", fontSize:"var(--t-2)", lineHeight:1.55,
            color:"var(--ink)", whiteSpace:"pre-wrap"
          }}>
{`SELECT
  c.challenge_id,
  c.customer_id,
  c.modality,
`}<span style={{color:"var(--verify)"}}>{`  -- L2  semantic · authentic fingerprint distance
  MIN(VEC_COSINE_DISTANCE(f_auth.embedding, c.current_embedding)) AS auth_distance,
  -- L2  semantic · nearest known-attack distance
  MIN(VEC_COSINE_DISTANCE(f_atk.embedding,  c.current_embedding)) AS attack_distance,
`}</span>{`
`}<span style={{color:"var(--alarm)"}}>{`  -- L3  episodic · htap columnar scan
  COUNT(CASE WHEN e.verdict='flagged' AND e.ts > NOW() - INTERVAL 90 DAY THEN 1 END) AS recent_flags,
  AVG(e.confidence) FILTER (WHERE e.ts > NOW() - INTERVAL 30 DAY) AS trailing_confidence,
`}</span>{`
`}<span style={{color:"oklch(0.45 0.14 75)"}}>{`  -- L4  procedural · active policy for tenant + tier
  p.policy_version, p.threshold_auth, p.threshold_attack, p.escalation_rule
`}</span>{`FROM active_challenges c
  LEFT JOIN authentic_fingerprints f_auth ON f_auth.customer_id = c.customer_id AND f_auth.modality = c.modality
  LEFT JOIN attack_fingerprints    f_atk  ON f_atk.modality   = c.modality
  LEFT JOIN episodic_events        e      ON e.customer_id    = c.customer_id
  LEFT JOIN procedural_policies    p      ON p.tenant_id = c.tenant_id AND p.risk_tier = c.risk_tier AND p.is_active = TRUE
WHERE c.challenge_id = ?
GROUP BY c.challenge_id, c.customer_id, c.modality,
         p.policy_version, p.threshold_auth, p.threshold_attack, p.escalation_rule;`}
          </pre>
          <Rule dashed style={{margin:"14px 0 10px"}}/>
          <div style={{display:"flex", gap:12, flexWrap:"wrap"}}>
            <Tag tone="ghost"><Dot tone="verify"/> L2 vector</Tag>
            <Tag tone="ghost"><Dot tone="alarm"/> L3 htap</Tag>
            <Tag tone="ghost"><Dot tone="amber"/> L4 policy</Tag>
            <Tag tone="ghost">one statement</Tag>
            <Tag tone="ghost">no sync · no etl</Tag>
          </div>
        </Card>

        <div style={{display:"flex", flexDirection:"column", gap:18}}>
          <Card title="Result row" inset>
            <KV rows={[
              ["challenge_id", F(layers?.challenge_id, "challenge.id")],
              ["auth_distance", <span className="num" style={{color: attack?"var(--alarm)":"var(--verify)"}}>{attack?"0.42":"0.08"}</span>],
              ["attack_distance", <span className="num" style={{color: attack?"var(--alarm)":"var(--ink)"}}>{attack?"0.06":"0.78"}</span>],
              ["recent_flags", F(layers?.recent_flags, "flags")],
              ["trailing_conf", F(layers?.trailing_confidence, "conf")],
              ["policy.v", F(layers?.policy_version, "v")],
              ["thresh_auth", "0.18"],
              ["thresh_attack", "0.25"],
            ]}/>
          </Card>
          <Card title="Chain of custody" inset>
            <div style={{display:"flex", flexDirection:"column", gap:6, fontSize:"var(--t-2)"}}>
              <ChainStep idx="01" label="sample received" tone="verify"/>
              <ChainStep idx="02" label="embedding computed · ECAPA"/>
              <ChainStep idx="03" label="htap query · tidb"/>
              <ChainStep idx="04" label="verdict signed · ed25519"/>
              <ChainStep idx="05" label="written to episodic · immutable"/>
            </div>
            <Rule dashed style={{margin:"10px 0"}}/>
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"flex-end"}}>
              <SigLine label="Reviewer · Aubric AML"/>
              <Stamp>ARTICLE 50</Stamp>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
};

const DistBar = ({ value, tone="ink", invert=false }) => {
  const pct = Math.max(0, Math.min(1, value));
  const toneVar = {alarm:"var(--alarm)", verify:"var(--verify)", ink:"var(--ink)"}[tone] || "var(--ink)";
  return (
    <div style={{position:"relative", height:14, border:"1px solid var(--ink)", background:"var(--paper-2)", marginBottom:4}}>
      <div style={{
        position:"absolute", top:0, bottom:0,
        left: invert ? `${pct*100}%` : 0,
        width: invert ? `${(1-pct)*100}%` : `${pct*100}%`,
        background: toneVar
      }}/>
      <div style={{
        position:"absolute", top:-2, bottom:-2,
        left:`${pct*100}%`, width:2, background:"var(--ink)"
      }}/>
      <div style={{
        position:"absolute", top:-6, left:`${pct*100}%`, transform:"translateX(-50%)",
        fontSize:"var(--t-1)", background:"var(--paper)", padding:"0 3px"
      }} className="num">{value.toFixed(2)}</div>
    </div>
  );
};

const LatencyLeg = ({ label, ms }) => (
  <div>
    <Eyebrow>{label}</Eyebrow>
    <div style={{fontSize:"var(--t-4)"}} className="num">
      {ms == null ? "—" : ms}<span style={{fontSize:"var(--t-2)", color:"var(--ink-3)"}}>ms</span>
    </div>
  </div>
);

const ChainStep = ({ idx, label, tone }) => (
  <div style={{display:"flex", gap:10, alignItems:"center"}}>
    <span className="num eyebrow" style={{color:"var(--ink-3)"}}>{idx}</span>
    <Dot tone={tone||""}/>
    <span style={{flex:1}}>{label}</span>
  </div>
);

window.ConsoleTab = ConsoleTab;
