// ─────────────────────────────────────────────────────────────────
// Aubric AML — backend hook layer.
// Real endpoints go here. Until then, functions RESOLVE WITH NULL so
// the UI renders explicit backend-hook placeholders rather than fake data.
// Swap the body of each function for a fetch() call when ready.
// ─────────────────────────────────────────────────────────────────

window.AML_API = (() => {
  const base = window.AML_BASE_URL || ""; // e.g. "https://api.aubric.ai/aml/v1"

  const hook = async (path, opts) => {
    // while backend is not wired, return null so UI shows {field} placeholders
    if (!base) return null;
    try {
      const r = await fetch(base + path, opts);
      if (!r.ok) return null;
      return await r.json();
    } catch { return null; }
  };

  return {
    // GET /challenges/:id  → active authenticity challenge record
    getChallenge:   (id)    => hook(`/challenges/${id}`),
    // POST /challenges/:id/query  → the 4-layer HTAP query
    runLayerQuery:  (id)    => hook(`/challenges/${id}/query`, { method: "POST" }),
    // GET /customers/:id/fingerprints  → Layer 2
    getFingerprints:(cid)   => hook(`/customers/${cid}/fingerprints`),
    // GET /customers/:id/episodic?days=90  → Layer 3
    getEpisodic:    (cid,d) => hook(`/customers/${cid}/episodic?days=${d||90}`),
    // GET /tenants/:id/policies  → Layer 4
    getPolicies:    (tid)   => hook(`/tenants/${tid}/policies`),
    // POST /update-cycles  → kick off branch+sandbox update loop
    startUpdateCycle: (body)=> hook(`/update-cycles`, { method: "POST", body: JSON.stringify(body) }),
    // GET /update-cycles/:id/stream  → SSE stream of 5 steps
    streamUpdateCycle:(id)  => hook(`/update-cycles/${id}/stream`),
    // GET /audit/branches  → archived branches (Article 50 evidence)
    listBranches:   ()      => hook(`/audit/branches`),
  };
})();

// Helper: render a backend-hook placeholder when a value is missing.
window.BH = function(field) {
  return `<span class="backend-hook">${field}</span>`;
};
