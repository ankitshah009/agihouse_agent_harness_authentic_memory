// Landing tab — Aubric AML product page, evidence-board register.
// Hero hard-decodes the AML pun, below: positioning, layers, loop, close.

const LandingTab = () => {
  return (
    <div className="paper" style={{minHeight:"100vh", paddingBottom:80}}>
      {/* top-nav strip */}
      <div style={{
        display:"flex", justifyContent:"space-between", alignItems:"center",
        padding:"18px 32px", borderBottom:"1px solid var(--ink)"
      }}>
        <div style={{display:"flex", gap:10, alignItems:"center"}}>
          <div style={{width:12, height:12, background:"var(--ink)"}}/>
          <span style={{fontFamily:"var(--mono)", fontSize:"var(--t-3)", letterSpacing:"0.06em"}}>AUBRIC · AML</span>
        </div>
        <div style={{display:"flex", gap:20}} className="eyebrow">
          <span>Memory</span><span>Update loop</span><span>Compliance</span><span>MCP</span><span>Docs</span>
        </div>
        <div style={{display:"flex", gap:8}}>
          <button className="btn">Sign in</button>
          <button className="btn primary">Request access</button>
        </div>
      </div>

      {/* ticker */}
      <Ticker items={[
        { label: "EU AI Act · Article 50 · enforces Aug 2 2026", tone:"alarm" },
        { label: "Aubric AML · public beta · Q2 2026", tone:"verify" },
        { label: "Backed by HTAP vector + branchable memory", tone:"" },
        { label: "MCP server · tidb.link/mcp", tone:"" },
        { label: "Daytona sandbox · <90ms start", tone:"" },
        { label: "Exa · adversarial OSINT monitoring", tone:"" },
      ]}/>

      {/* HERO */}
      <div style={{padding:"48px 32px 36px", display:"grid", gridTemplateColumns:"1.1fr 0.9fr", gap:40, alignItems:"start"}}>
        <div>
          <Eyebrow>Filed under / Trust &amp; Safety &middot; Financial Services</Eyebrow>
          <div className="serif" style={{
            fontSize:"clamp(56px, 7vw, 96px)", lineHeight:0.95, letterSpacing:"-0.035em", marginTop:14
          }}>
            AML for AI.
          </div>
          <div className="serif" style={{
            fontSize:"var(--t-5)", lineHeight:1.35, color:"var(--ink-2)",
            maxWidth:640, marginTop:20
          }}>
            The memory layer that lets a fraud-prevention agent remember who is real —
            and recognize everyone who isn&rsquo;t.
          </div>

          <div style={{display:"flex", gap:10, marginTop:28, flexWrap:"wrap"}}>
            <button className="btn primary">Request private beta</button>
            <button className="btn">Read the whitepaper ↗</button>
            <button className="btn">Watch the demo (3:00)</button>
          </div>

          <div style={{marginTop:36}}>
            <Eyebrow>Decode</Eyebrow>
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginTop:8, maxWidth:720}}>
              <div style={{borderLeft:"2px solid var(--ink)", paddingLeft:12}}>
                <div className="serif" style={{fontSize:"var(--t-5)", letterSpacing:"-0.01em"}}>Anti-Money Laundering</div>
                <div style={{fontSize:"var(--t-2)", color:"var(--ink-3)", marginTop:4}}>the register the buyer already operates in.</div>
              </div>
              <div style={{borderLeft:"2px solid var(--verify)", paddingLeft:12}}>
                <div className="serif" style={{fontSize:"var(--t-5)", letterSpacing:"-0.01em", color:"var(--verify)"}}>Authenticity Memory Layer</div>
                <div style={{fontSize:"var(--t-2)", color:"var(--ink-3)", marginTop:4}}>where we actually live.</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right column: case-file mockup */}
        <CaseFileMock/>
      </div>

      <Rule dotted style={{margin:"0 32px"}}/>

      {/* POSITIONING LINE */}
      <div style={{padding:"48px 32px", display:"grid", gridTemplateColumns:"240px 1fr", gap:32}}>
        <Eyebrow>Positioning</Eyebrow>
        <div className="serif" style={{fontSize:"var(--t-6)", letterSpacing:"-0.015em", lineHeight:1.25, maxWidth:1000}}>
          Aubric AML is the persistent memory substrate for trust-&amp;-safety agents.
          When an institution&rsquo;s agent decides whether a KYC video, a service call,
          or a document is authentic, it queries AML &mdash; and AML remembers everything
          the institution has ever seen about this customer, and about every attack
          it has ever faced.
        </div>
      </div>

      <Rule dotted style={{margin:"0 32px"}}/>

      {/* FOUR LAYERS STRIP */}
      <div style={{padding:"48px 32px"}}>
        <div style={{display:"flex", justifyContent:"space-between", alignItems:"end", marginBottom:20}}>
          <div>
            <Eyebrow>The memory</Eyebrow>
            <div className="serif" style={{fontSize:"var(--t-7)", letterSpacing:"-0.025em", marginTop:6}}>
              Four layers. One substrate.
            </div>
          </div>
          <div style={{fontSize:"var(--t-3)", color:"var(--ink-3)", maxWidth:360}} className="serif">
            Built on TiDB&rsquo;s HTAP engine &mdash; vector search, row-store writes, columnar scans
            and branchable state in a single cluster.
          </div>
        </div>

        <div style={{display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap:0, border:"1px solid var(--ink)"}}>
          {[
            {n:"01", k:"SHORT-TERM",  s:"active session",       d:"The current challenge row. Transactional, hot-path.", tech:"TiKV · row-store"},
            {n:"02", k:"SEMANTIC",    s:"fingerprints",          d:"Customer truth baselines and adversarial corpus — queried together.", tech:"VECTOR · HNSW"},
            {n:"03", k:"EPISODIC",    s:"every decision ever",   d:"Immutable log of every verdict, outcome and override. HTAP replicated.", tech:"TiFlash · columnar"},
            {n:"04", k:"PROCEDURAL",  s:"learned policy",        d:"Per-customer, per-tenant, per-vector rules — versioned, branchable.", tech:"SQL · version chain"}
          ].map((l, i) => (
            <div key={l.n} style={{
              padding:"24px 20px",
              borderRight: i===3 ? "none" : "1px solid var(--rule)",
              background: i%2===0 ? "var(--paper)" : "var(--paper-2)"
            }}>
              <div className="eyebrow">{l.n} &middot; {l.s}</div>
              <div className="serif" style={{fontSize:"var(--t-5)", letterSpacing:"-0.01em", marginTop:6}}>{l.k}</div>
              <div style={{fontSize:"var(--t-3)", color:"var(--ink-2)", marginTop:10, lineHeight:1.45}}>{l.d}</div>
              <div style={{marginTop:14}}><Tag tone="ghost">{l.tech}</Tag></div>
            </div>
          ))}
        </div>
      </div>

      <Rule dotted style={{margin:"0 32px"}}/>

      {/* UPDATE LOOP STRIP */}
      <div style={{padding:"48px 32px"}}>
        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:32, alignItems:"end", marginBottom:20}}>
          <div>
            <Eyebrow>How it stays honest</Eyebrow>
            <div className="serif" style={{fontSize:"var(--t-7)", letterSpacing:"-0.025em", marginTop:6, lineHeight:1.1}}>
              An update loop that never touches production.
            </div>
          </div>
          <div style={{fontSize:"var(--t-3)", color:"var(--ink-2)", fontFamily:"var(--serif)", lineHeight:1.5}}>
            Every cycle, drift signals are typed into hypotheses. TiDB branches the memory in milliseconds.
            Daytona spins a sandbox in under ninety. Ninety days of episodic are replayed. Exa pulls the
            generator off the open web. Only then &mdash; if the candidate wins on the replay and the gate &mdash;
            does it merge.
          </div>
        </div>

        <LandingLoopStrip/>
      </div>

      <Rule dotted style={{margin:"0 32px"}}/>

      {/* COMPLIANCE BAND */}
      <div style={{padding:"48px 32px", background:"var(--ink)", color:"var(--paper)", margin:"0 32px"}}>
        <div style={{display:"grid", gridTemplateColumns:"1fr 2fr", gap:40, alignItems:"end"}}>
          <div>
            <div style={{fontSize:"var(--t-1)", letterSpacing:"0.14em", opacity:0.7}}>COMPLIANCE · ARTICLE 50</div>
            <div style={{fontSize:"var(--t-9)", fontFamily:"var(--serif)", lineHeight:0.95, letterSpacing:"-0.035em", marginTop:14}}>
              T&minus;107d.
            </div>
          </div>
          <div style={{fontSize:"var(--t-5)", fontFamily:"var(--serif)", lineHeight:1.35, letterSpacing:"-0.01em", opacity:0.9}}>
            Article 50 enforcement lands August 2, 2026. Every branch promoted, every branch archived,
            every replay delta is signed and retained. Your audit defense is not assembled after the fact
            &mdash; it is the byproduct of how the system learns.
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <div style={{padding:"40px 32px 0", display:"grid", gridTemplateColumns:"1fr auto", gap:32, alignItems:"start"}}>
        <div>
          <Eyebrow>Aubric &middot; AML</Eyebrow>
          <div className="serif" style={{fontSize:"var(--t-5)", letterSpacing:"-0.01em", marginTop:6}}>
            The memory layer for trust-and-safety agents.
          </div>
          <div style={{fontSize:"var(--t-2)", color:"var(--ink-3)", marginTop:20}}>
            Built on TiDB · Daytona · Exa · MCP. Public beta scheduled Q2 2026.
          </div>
        </div>
        <div style={{display:"grid", gridTemplateColumns:"repeat(4, 120px)", gap:8}} className="eyebrow">
          <span>Memory</span><span>Loop</span><span>Compliance</span><span>MCP</span>
          <span>Security</span><span>VPC</span><span>Pricing</span><span>Docs</span>
        </div>
      </div>
    </div>
  );
};

const CaseFileMock = () => (
  <div style={{position:"relative"}}>
    <Xhair>
      <div style={{border:"1px solid var(--ink)", background:"var(--paper)", padding:"14px 16px"}}>
        <div style={{display:"flex", justifyContent:"space-between", marginBottom:10}}>
          <Eyebrow>Case file · live challenge</Eyebrow>
          <Tag tone="alarm"><Dot tone="alarm" pulse/> clone attempt</Tag>
        </div>
        <div className="serif" style={{fontSize:"var(--t-5)", letterSpacing:"-0.01em"}}>
          Wire authorization &mdash; <span className="num">$250,000</span>
        </div>
        <div style={{fontSize:"var(--t-2)", color:"var(--ink-3)", marginTop:4}}>Customer C-8821 &middot; Tenant ACME-FI &middot; Voice</div>

        <Rule dashed style={{margin:"14px 0"}}/>

        <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:14}}>
          <div>
            <Eyebrow>auth distance</Eyebrow>
            <div style={{fontSize:"var(--t-7)", letterSpacing:"-0.02em", color:"var(--alarm)"}} className="num">0.42</div>
            <div style={{fontSize:"var(--t-1)", color:"var(--ink-3)"}}>baseline match failed</div>
          </div>
          <div>
            <Eyebrow>attack distance</Eyebrow>
            <div style={{fontSize:"var(--t-7)", letterSpacing:"-0.02em", color:"var(--alarm)"}} className="num">0.06</div>
            <div style={{fontSize:"var(--t-1)", color:"var(--ink-3)"}}>cluster AX-418</div>
          </div>
        </div>

        <Rule dashed style={{margin:"14px 0"}}/>
        <Wave seed={9} tone="var(--alarm)" attack width={420} height={42}/>
        <div style={{display:"flex", justifyContent:"space-between", marginTop:10}}>
          <Tag tone="alarm">ESCALATE · HUMAN &lt;30s</Tag>
          <div className="eyebrow num">verdict · 94ms</div>
        </div>
      </div>
    </Xhair>
    <div style={{position:"absolute", top:-14, right:-14}}>
      <Stamp tone="alarm">EVIDENCE</Stamp>
    </div>
  </div>
);

const LandingLoopStrip = () => {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI(v => (v+1) % 5), 2200);
    return () => clearInterval(t);
  }, []);
  const steps = [
    { n:"01", k:"DRIFT",    a:"TIFLASH", t:"Typed hypothesis."},
    { n:"02", k:"BRANCH",   a:"TIDB × DAYTONA", t:"State + logic, isolated."},
    { n:"03", k:"REPLAY",   a:"SANDBOX", t:"90 days, re-decided."},
    { n:"04", k:"GATE",     a:"EXA", t:"Web evidence attached."},
    { n:"05", k:"PROMOTE",  a:"AUDIT LEDGER", t:"Winner merges. Loser archives."},
  ];
  return (
    <div style={{display:"grid", gridTemplateColumns:"repeat(5, 1fr)", gap:0, border:"1px solid var(--ink)"}}>
      {steps.map((s, idx) => (
        <div key={s.n} style={{
          padding:"20px 18px 22px",
          borderRight: idx===4 ? "none" : "1px solid var(--rule)",
          background: i===idx ? "var(--ink)" : "var(--paper)",
          color: i===idx ? "var(--paper)" : "var(--ink)",
          transition: "background 0.4s, color 0.4s",
          position:"relative", minHeight: 140
        }}>
          <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
            <span className="eyebrow" style={{color: i===idx ? "var(--paper)" : "var(--ink-3)"}}>STEP {s.n}</span>
            <span className="eyebrow" style={{color: i===idx ? "var(--paper)" : "var(--ink-3)"}}>{s.a}</span>
          </div>
          <div className="serif" style={{fontSize:"var(--t-6)", letterSpacing:"-0.02em", marginTop:10}}>{s.k}</div>
          <div style={{fontSize:"var(--t-3)", marginTop:6, color: i===idx ? "var(--paper)" : "var(--ink-2)", fontFamily:"var(--serif)"}}>{s.t}</div>
        </div>
      ))}
    </div>
  );
};

window.LandingTab = LandingTab;
